struct Vertex {
	GLfloat
		x, y, z, // position
		x1, y1, z1; // normal
};